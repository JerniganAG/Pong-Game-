#Pong Game Code
# Language - Python
# Modules - pygame, sys, random, 
# Controls - Arrow Keys left and right for player Paddle against AI

import pygame, sys, random
 
pygame.init()

WIDTH, HEIGHT = 1280, 720

FONT = pygame.font.SysFont("Consolas", int(WIDTH/20))

SCREEN = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Pong Use Up and Down Arrows To Move Paddle  Score 15 Points to Win!")
CLOCK = pygame.time.Clock()
#Colors
red = (203, 67, 53)
blue = (52, 152, 219)

#Win condition
maxScore = 15

#Music/Sound
Music = pygame.mixer.music.load('game-show-suspense.wav')
CollisonSound = pygame.mixer.Sound('retro-game.wav')
pygame.mixer.music.play(-1)
pygame.mixer.music.set_volume(0.4)

#Players score start of at zero
player_score = 0
opponent_score = 0

#Paddles player on right of screen and opponent on left side of screen
player = pygame.Rect(WIDTH-110, HEIGHT/2-50, 10,100)
opponent = pygame.Rect(110, HEIGHT/2-50, 10,100)

#Ball at center of screen
ball = pygame.Rect(WIDTH/2-10, HEIGHT/2-10, 20, 20)

#Speed variables for ball when x_speed is (-1) move left and(1) move right
#y_speed is 1 down and -1 go up
x_speed, y_speed =1, 1


# gameExit loop
gameExit = False

#While gameExit if false, QUIT gameExist is true stop while loop
while not gameExit:
  for event in pygame.event.get():
    if event.type == pygame.QUIT:
      gameExit = True

  #Keys press(input)
  keys_pressed = pygame.key.get_pressed()

  #move the player up by two and >0 stops player move off screen
  if keys_pressed[pygame.K_UP]:
    if player.top > 0:
      player.top -= 2
  #move the player down by two and < height stops player move off screen
  if keys_pressed[pygame.K_DOWN]:
    if player.bottom < HEIGHT:
      player.bottom += 2

#Update position of ball
  ball.x += x_speed * 2
  ball.y += y_speed * 2
  
  #Ball logic
  #Ball will bounce of bottom of screen
  if ball.y >= HEIGHT:
    y_speed = -1
  #Ball will bounce of top of screen
  if ball.y <= 0:
    y_speed = 1
  #Ball touch opponents side of the screen
  if ball.x <= 0:
    
  #Player score a point/ ball placed in random spot rest and go in random direction on screen
    player_score += 1
    #ball center screen
    ball.center = (WIDTH/2, HEIGHT/2)
    #ball goes in random direction
    x_speed, y_speed = random.choice([1, -1]), random.choice([1, -1])
  #opponent scores point touch right side of screen, ball random
  if ball.x >= WIDTH:
    opponent_score += 1
    ball.center = (WIDTH/2, HEIGHT/2)
    x_speed, y_speed = random.choice([1, -1]), random.choice([1, -1])
    #collision if ball hits paddle will bounce off in opposite direction and make sound
  if player.x - ball.width <= ball.x <= player.x and ball.y in range(player.top-ball.width, player.bottom+ball.width):
    x_speed = -1
    CollisonSound.play()
    
    #collision opponent paddle
  if opponent.x - ball.width <= ball.x <= opponent.x and ball.y in range(opponent.top-ball.width, opponent.bottom+ball.width):
    x_speed = 1
    CollisonSound.play()
    
  #Creating score display text objects
  player_score_text = FONT.render(":Score: "+ str(player_score), True, red)
  opponent_score_text = FONT.render(str(opponent_score), True, blue)

  

  #Create opponet "AI" if ball is below opponent move closer to ball and above the opponent move closer to the ball
  if opponent.y < ball.y:
    opponent.top += 1
  if opponent.bottom > ball.y:
    opponent.bottom -= 1

  #Fill screen black hide movement of paddle
  SCREEN.fill("black")

  #Create paddles and ball display on Screen(OUTPUT)
  pygame.draw.rect(SCREEN,red,player)
  pygame.draw.rect(SCREEN,blue,opponent)
  #10 radius of ball
  pygame.draw.circle(SCREEN,"White", ball.center,10)
  
  #Score display on screen
  SCREEN.blit(player_score_text, (WIDTH/3+50, 50))
  SCREEN.blit(opponent_score_text, (WIDTH/3-50, 50))

#Win condition
  if player_score == maxScore or opponent_score == maxScore:
    gameExit = True
    pygame.quit()
    sys.exit()

  pygame.display.update()
  CLOCK.tick(250)
pygame.quit()
quit()


