# CMIS226 - Assgignment 1
# Name: Alengta Jernigan
# Project Title:Pong
# Project Desciption:Pong is a classic arcade video game with two-dimensonal graphics that stimulates table tennis.
# Function Definitions:
#1. SCREEN = pygame.display.set_mode((WIDTH, HEIGHT)) returns the pygame.Surface object for the window and the set_mode() function how wide and how high to make the window in pixels,
#2. player = pygame.Rect(WIDTH-110, HEIGHT/2-50, 10,100)Rect object automatically calculates the coordinates for other features of the rectangle (width, height, and position x and y plane)
#3. player_score_text = FONT.render(str(player_score), True, "white")to create an image (Surface) of the text, then blit this image onto another Surface

#import modules

import pygame, sys
from pygame.locals import *
import os

pygame.init()

# set up the window
DISPLAYSURF = pygame.display.set_mode((500, 400), 0, 32)
pygame.display.set_caption('Game Scripting Assignment 1')

# set up the colors
BLACK = (  0,   0,   0)
WHITE = (255, 255, 255)
RED   = (255,   0,   0)
GREEN = (0, 100, 0)
BLUE  = (  0,   0, 255)

# draw on the surface object
DISPLAYSURF.fill(WHITE)

# set display fonts - NOTE: print(pygame.font.get_fonts()) will print the fonts on the system
font = pygame.font.SysFont('arialblack', 24)
font2 = pygame.font.SysFont('couriernew', 16)

# describe your project
course = font.render("CMIS 226 Assignment 1", True, RED)
name = font.render("Alengta Jernigan", True, BLUE)
title = font.render("Pong", True, GREEN)
desc1 = font2.render("Two Dimensional Sport Game", True, BLACK)
desc2 = font2.render("Score 15 Points to Win ", True, BLACK)
desc3 = font2.render("The Player Must Compete Against a Bot ", True, BLACK)
desc5 = font2.render("Use UP and Down Arrow to the Move Paddle", True, BLACK)
desc4 = font2.render("Click Screen to Start", True, BLUE)

# display the intro splash page
DISPLAYSURF.blit(course, (20,20))
pygame.draw.line(DISPLAYSURF, RED, (20, 55), (325, 55), 4)
DISPLAYSURF.blit(name, (20,70))
DISPLAYSURF.blit(title, (20,110))
DISPLAYSURF.blit(desc1, (20,150))
DISPLAYSURF.blit(desc2, (20,170))
DISPLAYSURF.blit(desc3, (20,190))
DISPLAYSURF.blit(desc4, (20,250))
DISPLAYSURF.blit(desc5, (20,210))

# run the game loop
while True:
    for event in pygame.event.get():
        if event.type == QUIT:
            pygame.quit()
            sys.exit()

         # If the user clicks the screen
        if event.type == pygame.MOUSEBUTTONDOWN:
            # Run a different Pygame code file
            import Asg3_Jernigan_Alengta
            
    pygame.display.update()
    
#Pong Game Code

